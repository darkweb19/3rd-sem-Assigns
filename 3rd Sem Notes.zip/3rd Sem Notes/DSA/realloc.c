#include<stdio.h>
#include<stdlib.h>
int main() {
    int *ptr ,n ;
    printf("Enter the size of array : ");
    scanf("%d", &n);
    //Calloc
    ptr =  (int *)calloc(n,sizeof(int));
    printf("Enter the elements :\n");
    for(int i = 0 ; i < n ; i++){
        scanf("%d", &ptr[i]);
    }

    printf("Printing the array  : \n");
    for(int i = 0; i<n ; i++){
        printf("%d\n",ptr[i]);
    }
    //realloc :
    //  "It is used for changing the size of  array without creating a new variable in heap memory"
    
        printf("Enter the size of new array : ");
        scanf("%d",&n);

        ptr = (int *)realloc(ptr, n*sizeof(int));
        printf("Enter the elements :\n");
        for(int i = 0 ; i <n ; i++){
            scanf("%d",&ptr[i]);
        }

        printf("Printing the new array: \n");
        for(int i = 0; i < n ; i++){
            printf("%d\n",ptr[i]);
        }
        free(ptr);
    return 0 ;   
}