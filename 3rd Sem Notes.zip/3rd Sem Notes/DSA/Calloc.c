#include<stdio.h>
#include<stdlib.h>  
int main(){
    //For Calloc...
     int *ptr ,n ;
    printf("Enter the size of array : ") ;
    scanf("%d",&n) ;
    ptr = (int*) calloc(n , sizeof(int ));
    
    printf("The elements are :\n") ;

    for(int i =  0 ; i < n ; i ++){ 
        printf("%d\n", ptr[i] );
    }

    //set NULL by default if user did not initializes the elements.....

    printf("The address is : %p", ptr);
    return 0 ;

}