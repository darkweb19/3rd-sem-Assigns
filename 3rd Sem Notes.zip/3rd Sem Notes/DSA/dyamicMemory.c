//SYNTATCITAL CODE FOR MALLOC AND CALLOC 
                    //malloc()
#include<stdio.h>
#include<stdlib.h>
int  main() {
	int *ptr , n ;
	printf("Enter  the size of the array : ");
	scanf("%d", &n);
	//for malloc:
	ptr = (int*)malloc(n*sizeof(int));
	printf("Enter the elements : \n");
	for(int i = 0 ; i<n ; i++){
		scanf("%d",&ptr[i]);
	}
	
	printf("Printing the array : \n");
	for(int i = 0;  i <n ; i++){
		printf("%d\n", ptr[i]);
	}
	
	printf("The address is : %p",ptr);	
	return 0 ;
}

/*
 NOTE:
dynamic memory allocation is nth but just the  value  create are stored in heap dynamically 
That means they have memory in  heap to store them    

syntax  for malloc: 
    ptr = (int*) malloc(10 * sizeof(int ));

syntax for calloc : 
    ptr = (int*) calloc( n ,sizeof(int ));

             IMP: if the input is not entered by user
             then compiler initializes it as o or NULL.



        (else all same as above:) 
syntax of realloc :

*/
