//DDA Algorithm for finding the points :
//Drawing the line in terminal is shown in BOOK >> 

//#CODE...>
#include<iostream> 
using namespace std;
int main(){
	//declaring and asking for inputs...
    float x1 , x2 ,y1, y2 ;
	cout << "Enter x1, y1, x2 and y2 : " << endl;
	cin >> x1 >> y1 >> x2 >> y2 ;

	float dx  = x2  - x1 ; 
	float dy = y2 - y1 ;
	int step ;
	//comparing for calculating the steps...
	if(dx > dy) {
		 step =  dx ;
	}
	else {
		step = dy ;
	}

	//printing steps...
    cout << "Steps : "  << step << endl;

	//declaring Increments...
	float xinC = dx/step ;
    cout << "Increment in x : " << xinC <<endl;
	float yinC = dy/step ;
    cout << "Increment in y : " << yinC <<endl;

	// printing points of X
	cout  <<  "Loop and printing : " << endl;
	for(int i =0 ; i <= step ; i++) {
		cout << "x: " << x1 << endl;
		x1 = x1 + xinC ;
	}
	// printing points of Y...

    for(int i = 0 ; i <=step ; i++) {
		cout << "  y: " << y1 << endl;
        y1 =  y1 + yinC ;
    }

	//just in case slope is needed for whatever idc...
    float slope = dy/dx ;;
    cout << "Slope : " << slope << endl;
	
	return 0;
}

//The given output  are the points of the line that are drawn in terminal for beginners: 

/*demerits :
      1. calculation of floating points takes extra time i.e. Time Complexity is Linear.
	  2. No smoooth lines
	  
*/